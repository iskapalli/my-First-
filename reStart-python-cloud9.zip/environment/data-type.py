myString = "This is a string."
print(myString)
print(type(myString))
print(myString + " is of the data type " + str(type(myString)))
firstString = "water"
secondString = "fall"
thirdString = firstString + secondString
print(thirdString)
name = input("What is your name? ")
print(name)
color = input("What is your favorite color?  ")
animal = input("What is your favorite animal?  ")
print("{}, you like a {} {}!".format(name,color,animal))
name = input("Name: ")
balance = 100.50

#Method 1:
print(name+" has $"+str(balance))

#Method 2:
print("%s has $%f"%(name,balance))
print("%-10s has $%.2f"%(name,balance))

#Method 3:
print("{} has ${}".format(name,balance))
print("{} has ${:.2f}".format(name,balance))
print("{:<10} has ${:.2f}".format(name,balance))
print("{:>10} has ${:.2f}".format(name,balance))
print("{:^10} has ${:.2f}".format(name,balance))
print("{:*^10} has ${:.2f}".format(name,balance))